#!/bin/bash
#SBATCH -J amanproj7b
#SBATCH -A cs475-575
#SBATCH -p class
#SBATCH -N 8 # number of nodes
#SBATCH -n 8 # number of tasks
#SBATCH --constraint=ib
#SBATCH -o proj7.out
#SBATCH -e proj7.err
#SBATCH --mail-type=BEGIN,END,FAIL
#SBATCH --mail-user=panditaa@oregonstate.edu
module load openmpi
mpic++ proj7.cpp -o proj7 -lm
for n in 1 2 4 6 8
do
mpiexec -mca btl self,tcp -np $n ./proj7
done